<?php

interface IMostrable
{
    public function mostrarHtml();
}


?>