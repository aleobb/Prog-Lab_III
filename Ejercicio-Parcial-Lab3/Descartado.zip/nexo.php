<?php

require_once ("Entidades/Alumno.php");
require_once ("Entidades/Archivo.php");

$queHago = isset($_POST['queHago']) ? $_POST['queHago'] : NULL;
$legajo = isset($_POST['legajo']) ? $_POST['legajo'] : NULL;
$nombre = isset($_POST['nombre']) ? $_POST['nombre'] : NULL;

/*
var_dump($_POST);
var_dump($_FILES);
var_dump($queHago);
*/

$rdo["Exito"] = FALSE;
$rdo["Mensaje"] = "Error de inicio";

/* *********** siempre le pegamos a nexo y por postman// cambia el metodo y los paramtros********** **/


switch($queHago){
	
	case "Subir":

		$rdo = Alumno::Agregar( new Alumno($legajo, $nombre) );
		echo $rdo["Mensaje"];

		break;
		
	case "Eliminar":
	
		$rdo = Alumno::Eliminar($legajo);
		echo $rdo["Mensaje"];

		break;

	case "Modificar":

		$rdo = Alumno::Modificar( new Alumno($legajo, $nombre) );
		echo $rdo["Mensaje"];

		break;

	case "Listar":
	
		$listaDeAlumnos = Alumno::TraerTodosLosRegistros();
		foreach($listaDeAlumnos as $item)
			echo $item->ToString();

		break;
		
	default:
		echo ":(";
}
?>