<?php
include "Identidades\IMostrable.php";

//include_once "Identidades\Localidad.php";
include_once "Identidades\Persona.php";
include_once "Identidades\Direccion.php";

$localidad = new Localidad("1834","Temperley");
$direccion = new Direccion("j.Rosso","698",$localidad);
$persona = new Persona("ale","ben","26010377",$direccion);


//echo "hola mundo";
echo "<br>";
//echo $persona->getNombre();


echo "<br>";
echo $persona->mostrarHtml();
echo "<br>";
echo "<br>";
echo "<br>";
//$nombre = "hola";

//echo $nombre;

// quilmes, avellaneda, lanus

?>