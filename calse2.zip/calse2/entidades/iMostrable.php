<?php 
interface iMostrable
{
     function mostrarHtml();
}
?>